
public class car{
	private String cid;
	private String ccarid;
	private String ccarname;
	private String ctype;
	private String ccolor;
	private String clevel;
	private String cinsurance;
	private String cprice;
	private String cimg;
	
	
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCcarid() {
		return ccarid;
	}
	public void setCcarid(String ccarid) {
		this.ccarid = ccarid;
	}
	public String getCcarname() {
		return ccarname;
	}
	public void setCcarname(String ccarname) {
		this.ccarname = ccarname;
	}
	public String getCtype() {
		return ctype;
	}
	public void setCtype(String ctype) {
		this.ctype = ctype;
	}
	public String getCcolor() {
		return ccolor;
	}
	public void setCcolor(String ccolor) {
		this.ccolor = ccolor;
	}
	public String getClevel() {
		return clevel;
	}
	public void setClevel(String clevel) {
		this.clevel = clevel;
	}
	public String getCinsurance() {
		return cinsurance;
	}
	public void setCinsurance(String cinsurance) {
		this.cinsurance = cinsurance;
	}
	public String getCprice() {
		return cprice;
	}
	public void setCprice(String cprice) {
		this.cprice = cprice;
	}
	public String getCimg() {
		return cimg;
	}
	public void setCimg(String cimg) {
		this.cimg = cimg;
	}
	public static void main(String[] args) {
        System.out.println("id"); 
    }
	
}


